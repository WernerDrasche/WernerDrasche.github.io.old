#!/usr/bin/python3

import sys
import pyperclip
import re

MODIFIER = [
            "private",
            "public",
            "protected",
            "final",
           ]

mode = sys.argv[1]
text = pyperclip.paste()
decs = re.sub("\n|\r", "", text).replace(",", " ").split(";")
del decs[-1]
output = ""
constructor = {"args": [], "body": []}
for i in range(len(decs)):
    statement = list(filter(lambda e: e and e not in MODIFIER, decs[i].split(" ")))
    stype, svars = statement[0], statement[1:]
    for var in svars:
        var_upper = "".join(c.upper() if i == 0 else c for i, c in enumerate(var))
        if "g" in mode:
            prefix = "get" if not stype == "boolean" else "is"
            output += "public %s %s%s() {\n" % (stype, prefix, var_upper) + \
                      "  return %s;\n" % (var,) + \
                      "}\n\n"
        if "s" in mode:
            output += "public void set%s(%s %s) {\n" % (var_upper, stype, var) + \
                      "  this.%s = %s; \n" % (var, var) + \
                      "}\n\n"
        if "c" in mode:
            constructor["args"].append(" ".join([stype, var]))
            constructor["body"].append("  this.%s = %s;\n" % (var, var))
if "c" in mode:
    class_name = sys.argv[2]
    args = ", ".join(constructor["args"])
    output += "public %s(%s) {\n" % (class_name, args)
    for statement in constructor["body"]: output += statement
    output += "}\n\n"
pyperclip.copy(output)
